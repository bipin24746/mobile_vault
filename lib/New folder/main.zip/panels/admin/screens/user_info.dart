import 'package:flutter/material.dart';

class userInfo extends StatelessWidget {
  const userInfo({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold();
  }
}
